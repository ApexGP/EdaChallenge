#pragma once
#include <vector>

namespace MBSO {
	using std::vector;
	using std::pair;

	// �����࣬�洢��ά����ÿ������洢һ��vector
	template<class T>
	class Grid
	{
	public:
		vector<vector<vector<T>>> grid; // ��ά����, ÿ��grid�洢һ��vector
		vector<pair<int, int>> usedId;  // ʹ�ù���grid id
		int sizeX, sizeY;

		Grid(int _sizeX, int _sizeY) :
			grid(_sizeX, vector<vector<T>>(_sizeY)),
			sizeX(_sizeX), sizeY(_sizeY)
		{
			usedId.reserve(sizeX * sizeY);
			for (int i = 0; i < sizeX; ++i)
				for (int j = 0; j < sizeY; ++j) grid[i][j].reserve(100);
		}
		Grid() : sizeX(0), sizeY(0) {}

		// ����grid��С
		void resize(int _sizeX, int _sizeY)
		{
			sizeX = _sizeX;
			sizeY = _sizeY;
			grid.resize(sizeX, vector<vector<T>>(sizeY));
			for (int i = 0; i < sizeX; ++i)
				for (int j = 0; j < sizeY; ++j) grid[i][j].reserve(100);
			usedId.clear();
			usedId.reserve(sizeX * sizeY);
		}

		// ����grid��С
		void reset(int _sizeX, int _sizeY)
		{
			resize(_sizeX, _sizeY);
		}

		// �������ʹ�ù���grid
		void clear()
		{
			int n = usedId.size();
			for (int i = 0; i < n; ++i)
			{
				if (grid[usedId[i].first][usedId[i].second].size() == 0) continue;
				grid[usedId[i].first][usedId[i].second].clear();
			}
			usedId.clear();
		}

		// ��grid[x][y]������Ԫ��element
		void emplace_back(int x, int y, T& element)
		{
			grid[x][y].emplace_back(element);
			usedId.emplace_back(x, y);
		}

		// ��ȡgrid[x][y]�е�vector
		vector<T>& getGridID(int x, int y)
		{
			return grid[x][y];
		}
	};

} // namespace MBSO