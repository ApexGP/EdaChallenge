#pragma once
#include "../const/Const.h"

namespace MBSO
{
	// ��ά�������
    class MPoint_2
    {
    public:
        int  x, y;
        MPoint_2() : x(0), y(0) {}

        MPoint_2(int _x, int _y) : x(_x), y(_y) {}

        // ���رȽϷ�
        bool operator==(const MPoint_2& p) const { return p.x == x && p.y == y; }
        bool operator<(const MPoint_2& p) const { return p.x == x ? y < p.y : x < p.x; }
        bool operator>(const MPoint_2& p) const { return p < (*this); }

        // ���ظ���
        MPoint_2 operator-() const { return MPoint_2(-x, -y); }

		// ���ؼӼ�
        MPoint_2 operator+(const MPoint_2& p) const { return MPoint_2(x + p.x, y + p.y); }
        MPoint_2 operator-(const MPoint_2& p) const { return MPoint_2(x - p.x, y - p.y); }

        // ���
        double operator^(const MPoint_2& p) const
        {
            return static_cast<double>(x) * static_cast<double>(p.y) - static_cast<double>(y) * static_cast<double>(p.x);
        }
        // ���
        double operator*(const MPoint_2& p) const
        {
            return static_cast<double>(x) * static_cast<double>(p.x) + static_cast<double>(y) * static_cast<double>(p.y);
        }
        
		// ��ȡ��������
        double length() const
        {
            return hypot(x, y);
        }
		// ��ȡx����
        int getX() const
        {
            return x;
        }
		// ��ȡy����
        int getY() const
        {
            return y;
        }

        // �ǵļнǣ��Ƕ���Ϊ this, �����˵�Ϊ p1, p2;
        double rad(const MPoint_2& p1, const MPoint_2& p2)
        {
            MPoint_2 v1(p1.x - x, p1.y - y);
            MPoint_2 v2(p2.x - x, p2.y - y);
            return radVector(v1, v2);
        }
        // �����н� [0, pi], ��������������
        double radVector(const MPoint_2& v1, const MPoint_2& v2)
        {
            double cross = v1 ^ v2;
            double dot = v1 * v2;
            double angle = fabs(atan2(fabs(cross), dot));
            return angle;
        }
    };

} // namespace MBSO