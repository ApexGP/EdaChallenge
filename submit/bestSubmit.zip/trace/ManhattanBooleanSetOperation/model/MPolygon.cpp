#include "MPolygon.h"

namespace MBSO {

	MPolygon::~MPolygon() {}
	MPolygon::MPolygon(DIR _dir) : dir(_dir),
		polygonSetId(0), existInterPoint(false),
		avgLength(0), isNested(false), isResultRecycle(false)
	{
	}

	MPolygon& MPolygon::operator=(const MPolygon& mpolygon)
	{
		if (this == &mpolygon) return *this;
		vertexs = mpolygon.vertexs;
		edges = mpolygon.edges;
		dir = mpolygon.dir;
		polygonSetId = mpolygon.polygonSetId;
		existInterPoint = mpolygon.existInterPoint;
		isNested = mpolygon.isNested;
		box = mpolygon.box;
		avgLength = mpolygon.avgLength;
		isResultRecycle = mpolygon.isResultRecycle;
		return *this;
	}
	MPolygon::MPolygon(const MPolygon& mpolygon)
	{
		if (this == &mpolygon) return;
		vertexs = mpolygon.vertexs;
		edges = mpolygon.edges;
		dir = mpolygon.dir;
		polygonSetId = mpolygon.polygonSetId;
		existInterPoint = mpolygon.existInterPoint;
		isNested = mpolygon.isNested;
		box = mpolygon.box;
		avgLength = mpolygon.avgLength;
		isResultRecycle = mpolygon.isResultRecycle;
	}
	MPolygon& MPolygon::operator=(MPolygon&& mpolygon) noexcept {
		if (this != &mpolygon) {
			vertexs = move(mpolygon.vertexs);
			edges = move(mpolygon.edges);
			dir = mpolygon.dir;
			polygonSetId = mpolygon.polygonSetId;
			existInterPoint = mpolygon.existInterPoint;
			isNested = mpolygon.isNested;
			box = mpolygon.box;
			avgLength = mpolygon.avgLength;
			isResultRecycle = mpolygon.isResultRecycle;
		}
		return *this;
	}
	MPolygon::MPolygon(MPolygon&& mpolygon) noexcept
	{
		if (this == &mpolygon) return;
		vertexs = move(mpolygon.vertexs);
		edges = move(mpolygon.edges);
		dir = mpolygon.dir;
		polygonSetId = mpolygon.polygonSetId;
		existInterPoint = mpolygon.existInterPoint;
		isNested = mpolygon.isNested;
		box = mpolygon.box;
		avgLength = mpolygon.avgLength;
		isResultRecycle = mpolygon.isResultRecycle;
	}

	void MPolygon::resetStatus()
	{
		existInterPoint = false;
		isNested = false;
		box.reset();
		avgLength = 0;
		isResultRecycle = false;

		int n = edges.size();
		if (n == 0)return;
		// �����߼�
		for (int i = 0; i < n; ++i) {
			// ����س�ʼ��
			auto vertex = edges[i]->ori; // ȡ�����
			edges[i]->dest = edges[(i + 1) % n]->ori; // ����
			vertex->resetFlags();
			vertex->polygonPtr = this;
			vertex->nextEdgeA = vertex->nextEdgeB = edges[i];
			vertex->frontEdgeA = vertex->frontEdgeB = edges[(i - 1 + n) % n];
			// ����س�ʼ��
			edges[i]->resetFlags();
			edges[i]->polygonPtr = this;
			// ������س�ʼ��
			avgLength += edges[i]->seg.getLength();
			box.update(vertex->point);
		}
		avgLength /= n;
	}

	bool MPolygon::isInside(const MPoint_2& point)
	{
		// ���߷��жϵ��Ƿ��������ٶ�����ڲ����������߽磩
		int crossings = 0;
		int x = point.getX();
		int y = point.getY();
		// ���ˮƽ���ߣ����ң���ߵĽ�����
		for (size_t i = 0; i < edges.size(); ++i) {
			int x1 = edges[i]->ori->point.getX();
			int y1 = edges[i]->ori->point.getY();
			int x2 = edges[i]->dest->point.getX();
			int y2 = edges[i]->dest->point.getY();

			// ���������ٶ���Σ���Ҫô��ˮƽ��Ҫô�Ǵ�ֱ��
			if (y1 == y2) continue; // ˮƽ�ߣ�����
			if (x1 < x) continue;   // ������ߵĴ�ֱ�ߣ�����
			if ((y1 <= y && y < y2) || (y2 <= y && y < y1)) { // ������������ұߵĴ�ֱ��y��Χ�н���
				crossings++;
			}
		}
		return (crossings % 2) == 1;
	}

} // namespace MBSO
