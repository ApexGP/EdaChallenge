#include "MVertex.h"

namespace MBSO {
	MVertex::MVertex() :
		polygonSetId(-1), polygonPtr(nullptr), isInter(false), isVisted(false),
		pointType(POINT_TYPE::POINT_2),
		nextEdgeA(nullptr), nextEdgeB(nullptr), frontEdgeA(nullptr), frontEdgeB(nullptr),
		anotherVertex(nullptr),
		isFinished(false), interType(INTER_TYPE::UNKNOWN), isResultRecycle(false)
	{
	};
	MVertex::MVertex(int _x, int _y, int _polygonSetId) :point(_x, _y), polygonSetId(_polygonSetId),
		polygonPtr(nullptr), isInter(false), isVisted(false), pointType(POINT_TYPE::POINT_2),
		nextEdgeA(nullptr), nextEdgeB(nullptr), frontEdgeA(nullptr), frontEdgeB(nullptr),
		anotherVertex(nullptr),
		isFinished(false), interType(INTER_TYPE::UNKNOWN), isResultRecycle(false)
	{
	};
	MVertex::MVertex(const MPoint_2& _p) :point(_p), polygonSetId(-1), polygonPtr(nullptr),
		isInter(false), isVisted(false), pointType(POINT_TYPE::POINT_2),
		nextEdgeA(nullptr), nextEdgeB(nullptr), frontEdgeA(nullptr), frontEdgeB(nullptr),
		anotherVertex(nullptr),
		isFinished(false), interType(INTER_TYPE::UNKNOWN), isResultRecycle(false)
	{
	};

	MVertex::~MVertex() {}

	// ��ȫ���ö���״̬
	void MVertex::resetAll()
	{
		point = MPoint_2();
		polygonSetId = -1;
		polygonPtr = nullptr;
		isInter = false;
		pointType = POINT_2;
		nextEdgeA = frontEdgeA = nullptr;
		nextEdgeB = frontEdgeB = nullptr;
		anotherVertex = nullptr;
		interP = MPoint_2();
		interType = UNKNOWN;
		isVisted = isFinished = false;
		isResultRecycle = false;
	}
	// ���ò����ڲ���ǣ�����������Ϣ �������ڶ�������ʱ����������Ϣ���ⲿ��ȷ��ֱ�Ӹ�ֵ���ڲ����ͨ��resetFlags���ã�
	void MVertex::resetFlags()
	{
		isInter = false;
		pointType = POINT_2;
		anotherVertex = nullptr;
		interP = MPoint_2();
		interType = UNKNOWN;
		isVisted = isFinished = false;
		isResultRecycle = false;
	}
}