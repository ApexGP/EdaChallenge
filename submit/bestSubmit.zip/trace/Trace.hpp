#pragma once
#include "public.h"
#include "Input.hpp"
#include "PolygonCutting.hpp"
#include "SpaceIndex.hpp"
#include "Intersect.hpp"
#include "Graph.hpp"
#include <queue>
#include <vector>
#include <limits>
#include <algorithm>

/* ��·׷�ٷ�װ������ */
class Trace {
private:
	Input& input;

public:
    Trace(Input& _input): input(_input){}

	/* ׷�ٷ���-���߳� */
	std::vector<int> TraceUsingCompleteGraph(); // ����ȫ��ͼ��BFS
	std::vector<int> TraceUsingLazyGraph();		// BFS�����ӳٽ�ͼ

	/* ׷�ٷ���-���߳� */
	std::vector<int> TraceUsingCompleteGraphParallel(int thread_count); // ����ȫ��ͼ��BFS
	std::vector<int> TraceUsingLazyGraphParallel(int thread_count);		// BFS�����ӳٽ�ͼ

private:
	// Lazy BFS����������չ���ɴ�����
	std::vector<int> RunLazyConnectedComponent(SpaceIndex& spaceIndex, Intersect& intersect, int start_id,
		std::vector<bool>& bfs_visted, const robin_hood::unordered_map<int, std::vector<int>>* extra_adj = nullptr);
	// ���а汾 Lazy BFS����������չ���ɴ�����
	std::vector<int> RunLazyConnectedComponentParallel(SpaceIndex &spaceIndex, Intersect &intersect, int start_id,
		std::vector<bool> &bfs_visted, const robin_hood::unordered_map<int, std::vector<int>> *extra_adj, int thread_count);
};

#pragma region implement

// ����ȫ��ͼ��BFS-���߳�
std::vector<int> Trace::TraceUsingCompleteGraph() {
	Timer myTimer;
	if (!input.has_gate_rule) // ��û��Gate����(�����)
	{
		/* ��������͹������ռ����� */
		std::cout << "----- Starting Space Index -----" << std::endl;
		SpaceIndex spaceIndex(input); 
		spaceIndex.CreatSpaceIndexMerged();	// Via��ͨ������ϲ�����
		spaceIndex.PrintSpaceIndexInfo();
		std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

		/* ��ȡ������ڶ����id */
		std::cout << "----- Starting Get StartPos -----" << std::endl;
		int start_pos_id = spaceIndex.GetStartPosinPolygonId(input.start_pos[0]);
		std::cout << "StartPos Polygon id:" << start_pos_id << std::endl;
		std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

		/* �ཻ����ȡ�߼� */
		std::cout << "----- Starting Intersection Test -----" << std::endl;
		Intersect intersect(input, spaceIndex);
		std::vector<Edge> edges = intersect.getAllEdge();
		std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

		/* ��ͼ������ͨ���� */
		std::cout << "----- Starting Get Connected Component -----" << std::endl;
		Graph graph(input.total_polygon);
		graph.AddEdges(edges);
		std::vector<int> component = graph.GetConnectedComponent(start_pos_id);
		std::cout << "s1 connected polygon size: " << component.size() << std::endl;
		std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

		return component;
	}
	else // ��Gate����(˫���)
	{
		/* PO�����κϲ���AA�������и� */
		std::cout << "----- Starting Merge and Cutting Polygon -----" << std::endl;
		PolygonCutting cutting(input);
		robin_hood::unordered_map<int, std::vector<Edge>> po_cut_edges = cutting.MergePOAndCutAA();
		std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

		/* ��������͹������ռ����� */
		std::cout << "----- Starting Space Index -----" << std::endl;
		SpaceIndex spaceIndex(input);
		spaceIndex.CreatSpaceIndexMerged();	// Via��ͨ������ϲ�����
		spaceIndex.PrintSpaceIndexInfo();
		std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

		/* ��ȡ������ڶ����id */
		std::cout << "----- Starting Get StartPos -----" << std::endl;
		int start_pos_s1_id = spaceIndex.GetStartPosinPolygonId(input.start_pos[0]);
		int start_pos_s2_id = spaceIndex.GetStartPosinPolygonId(input.start_pos[1]);
		std::cout << "StartPos s1 Polygon id:" << start_pos_s1_id << std::endl;
		std::cout << "StartPos s2 Polygon id:" << start_pos_s2_id << std::endl;
		std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

		/* �ཻ����ȡ�߼� */
		std::cout << "----- Starting Intersection Test -----" << std::endl;
		Intersect intersect(input, spaceIndex);
		std::vector<Edge> edges = intersect.getAllEdge();
		std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

		/* ��ͼ������ͨ���� */
		std::cout << "----- Starting Get Connected Component -----" << std::endl;
		Graph graph(input.total_polygon);
		graph.AddEdges(edges);
		// s1����ͨ�������ҵ����иߵ�ƽPO
		std::vector<int> component_s1 = graph.GetConnectedComponent(start_pos_s1_id);
		// ���ڸߵ�ƽPO, ��Ҫ�����������и��
		for (auto& id : component_s1) {
			if (input.polygons[id]->layer_id == input.gate_rule.first) { // PO��
				auto it = po_cut_edges.find(id);
				if (it != po_cut_edges.end()) { // ���и�������ӽ�ȥ
					for (auto& e : it->second) {
						edges.emplace_back(e);
					}
				}
			}
		}
		// ���½�ͼ����s2����ͨ����
		Graph new_graph(input.total_polygon);
		new_graph.AddEdges(edges);
		std::vector<int> component_s2 = new_graph.GetConnectedComponent(start_pos_s2_id);
		std::cout << "s1 connected polygon size: " << component_s1.size() << ", s2 connected polygon size: " << component_s2.size() << std::endl;
		std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

		return component_s2;
	}
}

// BFS�����ӳٽ�ͼ-���߳�
std::vector<int> Trace::TraceUsingLazyGraph() {
    Timer myTimer;
    if (!input.has_gate_rule) // ��û��Gate����(�����)
    {
        /* ��������͹������ռ����� */
        std::cout << "----- Starting Space Index -----" << std::endl;
        SpaceIndex spaceIndex(input);
		spaceIndex.CreatSpaceIndexSeparated();	//ÿ�������������
        spaceIndex.PrintSpaceIndexInfo();
        std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

        /* ��ȡ������ڶ����id */
        std::cout << "----- Starting Get StartPos -----" << std::endl;
        int start_pos_id = spaceIndex.GetStartPosinPolygonId(input.start_pos[0]);
        std::cout << "StartPos Polygon id:" << start_pos_id << std::endl;
        std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

        /* ���� BFS ��ȡ��ͨ���� */
        std::cout << "----- Starting Lazy BFS -----" << std::endl;
        Intersect intersect(input, spaceIndex);
        std::vector<bool> bfs_visted(input.total_polygon, false);
        std::vector<int> component = RunLazyConnectedComponent(spaceIndex, intersect, start_pos_id, bfs_visted);
		intersect.FlushStats();
        std::cout << "s1 connected polygon size: " << component.size() << std::endl;
        std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

        return component;
    }
	else // ��Gate����(˫���)
	{
		/* PO�����κϲ���AA�������и� */
		std::cout << "----- Starting Merge and Cutting Polygon -----" << std::endl;
		PolygonCutting cutting(input);
		robin_hood::unordered_map<int, std::vector<Edge>> po_cut_edges = cutting.MergePOAndCutAA();
		std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

		/* ��������͹������ռ����� */
		std::cout << "----- Starting Space Index -----" << std::endl;
		SpaceIndex spaceIndex(input);
		spaceIndex.CreatSpaceIndexSeparated();	//ÿ�������������
		spaceIndex.PrintSpaceIndexInfo();
		std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

		/* ��ȡ������ڶ����id */
		std::cout << "----- Starting Get StartPos -----" << std::endl;
		int start_pos_s1_id = spaceIndex.GetStartPosinPolygonId(input.start_pos[0]);
		int start_pos_s2_id = spaceIndex.GetStartPosinPolygonId(input.start_pos[1]);
		std::cout << "StartPos s1 Polygon id:" << start_pos_s1_id << std::endl;
		std::cout << "StartPos s2 Polygon id:" << start_pos_s2_id << std::endl;
		std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

		Intersect intersect(input, spaceIndex);
		std::vector<bool> bfs_visted(input.total_polygon, false);

		/* s1 ���� BFS */
		std::cout << "----- Starting Lazy BFS (s1) -----" << std::endl;
		std::vector<int> component_s1 = RunLazyConnectedComponent(spaceIndex, intersect, start_pos_s1_id, bfs_visted);
		intersect.FlushStats();
		std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

		/* ���������и�߲�ִ�� s2 ���� BFS */
		std::cout << "----- Starting Lazy BFS (s2) -----" << std::endl;
		robin_hood::unordered_map<int, std::vector<int>> extra_adj;
		extra_adj.reserve(po_cut_edges.size());
		for (auto& id : component_s1) {
			if (input.polygons[id]->layer_id != input.gate_rule.first) continue;
			auto it = po_cut_edges.find(id);
			if (it == po_cut_edges.end()) continue;
			for (auto& edge : it->second) {
				extra_adj[edge.first].push_back(edge.second);
				extra_adj[edge.second].push_back(edge.first);
			}
		}
		bfs_visted.assign(input.total_polygon, false);
		std::vector<int> component_s2 = RunLazyConnectedComponent(spaceIndex, intersect, start_pos_s2_id, bfs_visted, &extra_adj);
		intersect.FlushStats();
		std::cout << "s1 connected polygon size: " << component_s1.size() << ", s2 connected polygon size: " << component_s2.size() << std::endl;
		std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

		return component_s2;
	}
}

// ����ȫ��ͼ��BFS-���߳�
std::vector<int> Trace::TraceUsingCompleteGraphParallel(int thread_count) {
	Timer myTimer;
	if (!input.has_gate_rule) // ��û��Gate����(�����)
	{
		/* ��������͹������ռ����� */
		std::cout << "----- Starting Space Index -----" << std::endl;
		SpaceIndex spaceIndex(input);
		spaceIndex.CreatSpaceIndexMergedParallel(thread_count);	// Via��ͨ������ϲ�����
		spaceIndex.PrintSpaceIndexInfo();
		std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

		/* ��ȡ������ڶ����id */
		std::cout << "----- Starting Get StartPos -----" << std::endl;
		int start_pos_id = spaceIndex.GetStartPosinPolygonIdParallel(input.start_pos[0], thread_count);
		std::cout << "StartPos Polygon id:" << start_pos_id << std::endl;
		std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

		/* �ཻ����ȡ�߼� */
		std::cout << "----- Starting Intersection Test -----" << std::endl;
		Intersect intersect(input, spaceIndex);
		std::vector<Edge> edges = intersect.getAllEdgeParallel(thread_count);
		std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

		/* ��ͼ������ͨ���� */
		std::cout << "----- Starting Get Connected Component -----" << std::endl;
		Graph graph(input.total_polygon);
		graph.AddEdges(edges);
		std::vector<int> component = graph.GetConnectedComponent(start_pos_id);
		std::cout << "s1 connected polygon size: " << component.size() << std::endl;
		std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

		return component;
	}
	else // ��Gate����(˫���)
	{
		/* PO�����κϲ���AA�������и� */
		std::cout << "----- Starting Merge and Cutting Polygon -----" << std::endl;
		PolygonCutting cutting(input);
		robin_hood::unordered_map<int, std::vector<Edge>> po_cut_edges = cutting.MergePOAndCutAAParallel(thread_count);
		std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

		/* ��������͹������ռ����� */
		std::cout << "----- Starting Space Index -----" << std::endl;
		SpaceIndex spaceIndex(input);
		spaceIndex.CreatSpaceIndexMergedParallel(thread_count);	// Via��ͨ������ϲ�����
		spaceIndex.PrintSpaceIndexInfo();
		std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

		/* ��ȡ������ڶ����id */
		std::cout << "----- Starting Get StartPos -----" << std::endl;
		int start_pos_s1_id = spaceIndex.GetStartPosinPolygonIdParallel(input.start_pos[0], thread_count);
		int start_pos_s2_id = spaceIndex.GetStartPosinPolygonIdParallel(input.start_pos[1], thread_count);
		std::cout << "StartPos s1 Polygon id:" << start_pos_s1_id << std::endl;
		std::cout << "StartPos s2 Polygon id:" << start_pos_s2_id << std::endl;
		std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

		/* �ཻ����ȡ�߼� */
		std::cout << "----- Starting Intersection Test -----" << std::endl;
		Intersect intersect(input, spaceIndex);
		std::vector<Edge> edges = intersect.getAllEdgeParallel(thread_count);
		std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

		/* ��ͼ������ͨ���� */
		std::cout << "----- Starting Get Connected Component -----" << std::endl;
		Graph graph(input.total_polygon);
		graph.AddEdges(edges);
		// s1����ͨ�������ҵ����иߵ�ƽPO
		std::vector<int> component_s1 = graph.GetConnectedComponent(start_pos_s1_id);
		// ���ڸߵ�ƽPO, ��Ҫ�����������и��
		for (auto& id : component_s1) {
			if (input.polygons[id]->layer_id == input.gate_rule.first) { // PO��
				auto it = po_cut_edges.find(id);
				if (it != po_cut_edges.end()) { // ���и�������ӽ�ȥ
					for (auto& e : it->second) {
						edges.emplace_back(e);
					}
				}
			}
		}
		// ���½�ͼ����s2����ͨ����
		Graph new_graph(input.total_polygon);
		new_graph.AddEdges(edges);
		std::vector<int> component_s2 = new_graph.GetConnectedComponent(start_pos_s2_id);
		std::cout << "s1 connected polygon size: " << component_s1.size() << ", s2 connected polygon size: " << component_s2.size() << std::endl;
		std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

		return component_s2;
	}
}

// BFS�����ӳٽ�ͼ-���߳�
std::vector<int> Trace::TraceUsingLazyGraphParallel(int thread_count) {
	Timer myTimer;
    if (!input.has_gate_rule) // ��û��Gate����(�����)
    {
        /* ��������͹������ռ����� */
        std::cout << "----- Starting Space Index -----" << std::endl;
        SpaceIndex spaceIndex(input);
		spaceIndex.CreatSpaceIndexSeparatedParallel(thread_count);	//ÿ�������������
        spaceIndex.PrintSpaceIndexInfo();
        std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

        /* ��ȡ������ڶ����id */
        std::cout << "----- Starting Get StartPos -----" << std::endl;
        int start_pos_id = spaceIndex.GetStartPosinPolygonIdParallel(input.start_pos[0], thread_count);
        std::cout << "StartPos Polygon id:" << start_pos_id << std::endl;
        std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

        /* ���� BFS ��ȡ��ͨ���� */
        std::cout << "----- Starting Lazy BFS -----" << std::endl;
        Intersect intersect(input, spaceIndex);
        std::vector<bool> bfs_visted(input.total_polygon, false);
        std::vector<int> component = RunLazyConnectedComponentParallel(spaceIndex, intersect, start_pos_id, bfs_visted, nullptr, thread_count);
		intersect.FlushStats();
        std::cout << "s1 connected polygon size: " << component.size() << std::endl;
        std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

        return component;
    }
	else // ��Gate����(˫���)
	{
		/* PO�����κϲ���AA�������и� */
		std::cout << "----- Starting Merge and Cutting Polygon -----" << std::endl;
		PolygonCutting cutting(input);
		robin_hood::unordered_map<int, std::vector<Edge>> po_cut_edges = cutting.MergePOAndCutAAParallel(thread_count);
		std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

		/* ��������͹������ռ����� */
		std::cout << "----- Starting Space Index -----" << std::endl;
		SpaceIndex spaceIndex(input);
		spaceIndex.CreatSpaceIndexSeparatedParallel(thread_count);	//ÿ�������������
		spaceIndex.PrintSpaceIndexInfo();
		std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

		/* ��ȡ������ڶ����id */
		std::cout << "----- Starting Get StartPos -----" << std::endl;
		int start_pos_s1_id = spaceIndex.GetStartPosinPolygonIdParallel(input.start_pos[0], thread_count);
		int start_pos_s2_id = spaceIndex.GetStartPosinPolygonIdParallel(input.start_pos[1], thread_count);
		std::cout << "StartPos s1 Polygon id:" << start_pos_s1_id << std::endl;
		std::cout << "StartPos s2 Polygon id:" << start_pos_s2_id << std::endl;
		std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

		Intersect intersect(input, spaceIndex);
		std::vector<bool> bfs_visted(input.total_polygon, false);

		/* s1 ���� BFS */
		std::cout << "----- Starting Lazy BFS (s1) -----" << std::endl;
		std::vector<int> component_s1 = RunLazyConnectedComponentParallel(spaceIndex, intersect, start_pos_s1_id, bfs_visted, nullptr, thread_count);
		intersect.FlushStats();
		std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

		/* ���������и�߲�ִ�� s2 ���� BFS */
		std::cout << "----- Starting Lazy BFS (s2) -----" << std::endl;
		robin_hood::unordered_map<int, std::vector<int>> extra_adj;
		extra_adj.reserve(po_cut_edges.size());
		for (auto& id : component_s1) {
			if (input.polygons[id]->layer_id != input.gate_rule.first) continue;
			auto it = po_cut_edges.find(id);
			if (it == po_cut_edges.end()) continue;
			for (auto& edge : it->second) {
				extra_adj[edge.first].push_back(edge.second);
				extra_adj[edge.second].push_back(edge.first);
			}
		}
		bfs_visted.assign(input.total_polygon, false);
		std::vector<int> component_s2 = RunLazyConnectedComponentParallel(spaceIndex, intersect, start_pos_s2_id, bfs_visted, &extra_adj, thread_count);
		intersect.FlushStats();
		std::cout << "s1 connected polygon size: " << component_s1.size() << ", s2 connected polygon size: " << component_s2.size() << std::endl;
		std::cout << "----- Use Time: " << myTimer.FromLastCallElapsed() << " s" << std::endl << std::endl;

		return component_s2;
	}
}

// Lazy BFS����������չ���ɴ�����
std::vector<int> Trace::RunLazyConnectedComponent(SpaceIndex& spaceIndex, Intersect& intersect, int start_id,
	std::vector<bool>& bfs_visted, const robin_hood::unordered_map<int, std::vector<int>>* extra_adj) {
	if (start_id < 0 || start_id >= input.total_polygon) return {};

	const Polygon* start_poly = input.polygons[start_id];
	const std::string& start_layer_name = start_poly ? input.layer_id_to_name[start_poly->layer_id] : std::string("unknown");

	std::cout << "[LazyBFS] start id=" << start_id << " layer=" << start_layer_name << std::endl;

	std::queue<int> bfs_queue;
	bfs_queue.push(start_id);
	bfs_visted[start_id] = true;

	std::vector<int> component;
	component.reserve(1000000);
	std::vector<int> neighbors;
	neighbors.reserve(100);

	size_t expansions = 0;
	size_t neighbor_candidates = 0;
	size_t extra_neighbors = 0;
	size_t skipped_visited = 0;
	size_t enqueued = 0;

	while (!bfs_queue.empty()) {
		int current = bfs_queue.front();
		bfs_queue.pop();
		component.push_back(current);
		++expansions;

		// ���ڵ�ǰ�����id��ȡ�����ھӶ����
		neighbors.clear();
		intersect.GetNeighborsLazy(current, bfs_visted, neighbors);
		neighbor_candidates += neighbors.size();

		// �Ƿ��ж����и����Ҫ����
		if (extra_adj) {
			auto it = extra_adj->find(current);
			if (it != extra_adj->end()) {
				extra_neighbors += it->second.size();
				neighbors.insert(neighbors.end(), it->second.begin(), it->second.end());
			}
		}

		// δ�����ھ����
		for (int next : neighbors) {
			if (!bfs_visted[next]) {
				bfs_visted[next] = true;
				bfs_queue.push(next);
				++enqueued;
			}
			else {
				++skipped_visited;
			}
		}
	}

	std::cout << "[LazyBFS] summary start_id=" << start_id
		<< " visited=" << component.size()
		<< " expansions=" << expansions
		<< " neighbors=" << neighbor_candidates
		<< " extra_neighbors=" << extra_neighbors
		<< " skipped_visited=" << skipped_visited
		<< " enqueued=" << enqueued << std::endl;

	return component;
}

// ���а汾��Lazy BFS����������չ���ɴ�����
std::vector<int> Trace::RunLazyConnectedComponentParallel(SpaceIndex& spaceIndex, Intersect& intersect, int start_id,
	std::vector<bool>& bfs_visted, const robin_hood::unordered_map<int, std::vector<int>>* extra_adj, int thread_count) {
	if (start_id < 0 || start_id >= input.total_polygon) return {};

	const Polygon* start_poly = input.polygons[start_id];
	const std::string& start_layer_name = start_poly ? input.layer_id_to_name[start_poly->layer_id] : std::string("unknown");

	std::cout << "[LazyBFS] start id=" << start_id << " layer=" << start_layer_name << std::endl;

	std::queue<int> bfs_queue;
	bfs_queue.push(start_id);
	bfs_visted[start_id] = true;

	std::vector<int> component;
	component.reserve(1000000);

	size_t expansions = 0;
	size_t neighbor_candidates = 0;
	size_t extra_neighbors = 0;
	size_t skipped_visited = 0;
	size_t enqueued = 0;

	// �������ݽṹ
	std::vector<int> current_level;
	std::vector<std::vector<int>> neighbors_list;
	neighbors_list.reserve(1000);  // Ԥ�����������

	// ���ò�����ֵ
    const size_t PARALLEL_THRESHOLD = 100; // �ɵ����Ĳ�����ֵ

	omp_set_num_threads(thread_count);
	while (!bfs_queue.empty()) {
	    // ������ǰ�㼶�����нڵ�
	    size_t level_size = bfs_queue.size();
	    expansions += level_size;
	
	    // ׼����ǰ�㼶�ڵ�
    	current_level.clear();
    	current_level.reserve(level_size);
		
    	// �����ھ��б���С����������������
    	if (neighbors_list.size() < level_size) {
    	    size_t prev_size = neighbors_list.size();
    	    neighbors_list.resize(level_size);
    	    // Ϊ��Ԫ��Ԥ�����ڴ�
    	    for (size_t i = prev_size; i < level_size; ++i) {
    	        neighbors_list[i].reserve(100);
    	    }
    	}
	
	    // ���ӵ�ǰ�㼶�ڵ�
	    for (size_t i = 0; i < level_size; ++i) {
	        int current = bfs_queue.front();
	        bfs_queue.pop();
	        current_level.push_back(current);
	        component.push_back(current);
	    }

		if (level_size > PARALLEL_THRESHOLD) {
			// ���л�ȡ�ھ� (ʹ�� OpenMP) ����̬����С���������У����ؾ���
            #pragma omp parallel for schedule(dynamic, 50) reduction(+:neighbor_candidates, extra_neighbors)
            for (size_t i = 0; i < level_size; ++i) {
                int current = current_level[i];
                // �����ھ�����������������
                neighbors_list[i].clear();
                // ��ȡ�����ھ�
                intersect.GetNeighborsLazyParallel(current, bfs_visted, neighbors_list[i]);
                neighbor_candidates += neighbors_list[i].size();
                // ���Ӷ����ھ�
                if (extra_adj) {
                    auto it = extra_adj->find(current);
                    if (it != extra_adj->end()) {
                        const auto& extra = it->second;
                        extra_neighbors += extra.size();
                        neighbors_list[i].insert(neighbors_list[i].end(), extra.begin(), extra.end());
                    }
                }
            }
        } else {
            // ���д���С�㼶
            for (size_t i = 0; i < level_size; ++i) {
                int current = current_level[i];
                neighbors_list[i].clear();
                // ��ȡ�����ھ�
                intersect.GetNeighborsLazyParallel(current, bfs_visted, neighbors_list[i]);
                neighbor_candidates += neighbors_list[i].size();
                // ���Ӷ����ھ�
                if (extra_adj) {
                    auto it = extra_adj->find(current);
                    if (it != extra_adj->end()) {
                        const auto& extra = it->second;
                        extra_neighbors += extra.size();
                        neighbors_list[i].insert(neighbors_list[i].end(), extra.begin(), extra.end());
                    }
                }
            }
        }

		// �����ھӽڵ㣨ͳһ��������/���н����
	    for (size_t i = 0; i < level_size; ++i) {
	        for (int next : neighbors_list[i]) {
	            if (!bfs_visted[next]) {
	                bfs_visted[next] = true;
	                bfs_queue.push(next);
	                ++enqueued;
	            } else {
	                ++skipped_visited;
	            }
	        }
	    }
	}

	std::cout << "[LazyBFS] summary start_id=" << start_id
		<< " visited=" << component.size()
		<< " expansions=" << expansions
		<< " neighbors=" << neighbor_candidates
		<< " extra_neighbors=" << extra_neighbors
		<< " skipped_visited=" << skipped_visited
		<< " enqueued=" << enqueued << std::endl;

	return component;
}

#pragma endregion
